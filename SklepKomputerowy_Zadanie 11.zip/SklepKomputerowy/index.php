<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="utf-8">
        <title>Nasz sklep komputerowy</title>
        <link rel="stylesheet" href="styl8.css">
    </head>
    <body>
        <div id="menu">
            <a href="index.php">Główna</a>
            <a href="procesory.html">Procesory</a>
            <a href="ram.html">RAM</a>
            <a href="grafika.html">Grafika</a>
        </div>
        <div id="logo">
            <h2>Podzespoły komputerowe</h2>
        </div>
        <div id="main">
            <h1>Dzisiejsze promocje</h1>
            <table>
                <th>NUMER</th><th>NAZWA PODZESPOŁU</th><th>OPIS</th><th>CENA</th>
                <?php
                $host = 'localhost';
                $username = 'root';
                $dbname = 'sklep2';
                $pass = '';

                $conn = mysqli_connect($host, $username, $pass, $dbname);
                if (!$conn) {
                    die ("Błąd połączenia z bazą danych!!");
                }
                $sql = "SELECT id, nazwa, opis, cena FROM podzespoly WHERE cena<1000";
                $result = mysqli_query($conn, $sql);

                if (mysqli_num_rows($result)>0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>
                        <td>" . $row['id'] . "</td>
                        <td>" . $row['nazwa'] . "</td>
                        <td>" . $row['opis'] . "</td>
                        <td>" . $row['cena'] . "</td>
                        </tr>";
                    }
                } else {
                    echo "Brak danych.";
                }
                mysqli_close($conn);
                ?>
            </table>
        </div>
        <div id="footer1">
            <img src="scalak.jpg" alt="promocje na procesory">
        </div>
        <div id="footer2">
            <h4>Nasz Sklep Komputerowy</h4>
            <p>Współpracujemy z hurtownią <a target="_blank" href="http://www.edata.pl">edata</a></p>
        </div>
        <div id="footer3">
            <p>zadzwoń: 601 602 603</p>
        </div>
        <div id="footer4">
            <p>Stronę wykonał: 00000000000</p>
        </div>
    </body>
</html>