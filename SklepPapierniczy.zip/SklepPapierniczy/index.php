<!DOCTYPE HTML>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta name=viewport content=width=device-width, initial-scale=1.0>
        <title>Sklep dla uczniów</title>
        <link rel="stylesheet" href="styl.css">
    </head>
    <body>
        <div id="banner">
            <h1>Dzisiejsze promocje naszego sklepu</h1>
        </div>
        <div id="lewy">
            <h2>Taniej o 30%</h2>
            <ol type="a"><b>
                <?php
                $dbname = 'papierniczy';
                $host = 'localhost';
                $username = 'root';
                $pass = '';

                $conn = mysqli_connect($host, $username, $pass, $dbname);
                if (!$conn) {
                    die ("Błąd połączenia z bazą danych");
                }
                $sql = "SELECT nazwa FROM towary WHERE promocja=1";
                $result = mysqli_query($conn, $sql);
                if (mysqli_num_rows($result)>0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<li>". $row ['nazwa']."</li>";
                    }
                } else {
                    echo "Brak Danych!!";
                }
                mysqli_close($conn);
                ?>
            </b></ol>
        </div>
        <div id="srodek">
            <h2>Sprawdź cenę</h2>
            <form action="index.php" method="post">
                <select name="option">
                    <option>Gumka do mazania</option>
                    <option>Cienkopis</option>
                    <option>Pisaki 60 szt.</option>
                    <option>Markery 4 szt.</option>
                </select>
                <button type="submit">SPRAWDŹ</button>
                <?php
                $opcja = $_POST['option'];

                $dbname = 'papierniczy';
                $host = 'localhost';
                $username = 'root';
                $pass = '';

                $conn = mysqli_connect($host, $username, $pass, $dbname);
                if (!$conn) {
                    die ("Błąd połączenia z bazą danych");
                }
                $sql = "SELECT cena FROM towary WHERE nazwa=('$opcja')";
                $result = mysqli_query($conn, $sql);
                if (mysqli_num_rows($result)>0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<br>"."cena regularna: ".$opcja." ".$row ['cena']."</br>";
                        $cenaProm = $row ['cena'] *0.7;
                        echo "<br>"."cena w promocji 30%: ".$cenaProm."</br>";
                    }
                } else {
                    echo "Brak Danych!!";
                }
                mysqli_close($conn);
                ?>
            </form>
        </div>
        <div id="prawy">
            <h2>Kontakt</h2>
            <p>e-mail: <a href="bok@sklep.pl">bok@sklep.pl</a></p>
            <img src="promocja.png" alt="promocja">
        </div>
        <div id="footer">
            <h4>Autor strony: 0000000000</h4>
        </div>
    </body>
</html>